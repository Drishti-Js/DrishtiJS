#!/bin/sh
set -eu
source_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
prefix="${HOME}/.local/bin"
if [ "$#" -gt 0 ]; then
  if [ "$#" -ne 2 ] || [ "$1" != "--prefix" ]; then
    echo "Usage: install.sh [--prefix /path/to/bin]" >&2; exit 1
  fi
  prefix=$2
fi
mkdir -p "$prefix"
for name in drish drishti_runtime create-drishti Drishti-Create-NewVisionApp; do
  cp "$source_dir/bin/$name" "$prefix/$name"
  chmod 755 "$prefix/$name"
done
echo "Installed Drishti into $prefix. Ensure this directory is on PATH."
